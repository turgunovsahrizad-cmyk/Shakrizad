# VekermanVisual (Fabric 1.21.4, Java 21)

Client-only, visual/optimization mod. Opens with **Right Shift** or the **VekermanVisual** button on the pause screen.

Build: push to GitHub, the `build` workflow produces the JAR (Actions -> artifact `VekermanVisual`).
Locally: Gradle 8.12+ and `gradle build` -> `build/libs/VekermanVisual-1.0.0.jar`.

Configs: `<game dir>/VekermanVisual/configs/<name>.json` (folders are created on first launch),
current state in `VekermanVisual/current.json`, waypoints in `VekermanVisual/waypoints.json`.

Known gaps: Motion Blur has no renderer yet (toggle/strength are stored only).
