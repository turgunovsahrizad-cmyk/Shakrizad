package com.vekerman.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VekermanVisual implements ClientModInitializer {
    public static final String NAME = "VekermanVisual";
    public static final Logger LOG = LoggerFactory.getLogger(NAME);
    private static boolean guiKeyDown;
    private static boolean tickErr;

    @Override
    public void onInitializeClient() {
        try { ConfigManager.init(); } catch (Throwable t) { LOG.error("init failed", t); }
        ClientTickEvents.END_CLIENT_TICK.register(VekermanVisual::tick);
        HudRenderCallback.EVENT.register(Hud::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigManager.saveCurrent());
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            try { if (world.isClient && Modules.DAMAGE != null) Modules.DAMAGE.onAttack(entity); } catch (Throwable ignored) {}
            return ActionResult.PASS;
        });
        // Button on the pause screen: handy on Android where Right Shift is awkward.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("VekermanVisual"),
                        b -> client.setScreen(new ClickGuiScreen(screen))).dimensions(6, 6, 100, 20).build());
            }
        });
        LOG.info("{} loaded", NAME);
    }

    private static void tick(MinecraftClient mc) {
        try {
            if (mc.getWindow() == null) return;
            long win = mc.getWindow().getHandle();
            boolean rs = InputUtil.isKeyPressed(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (rs && !guiKeyDown && mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGuiScreen(null));
            guiKeyDown = rs;

            for (Module m : Modules.ALL) {
                m.sync(mc);
                if (m.bind >= 0 && !m.hold) {
                    boolean d = InputUtil.isKeyPressed(win, m.bind);
                    if (d && !m.bindDown && mc.currentScreen == null && mc.player != null) m.onBind(mc);
                    m.bindDown = d;
                }
                if (m.enabled) m.onTick(mc);
            }
            FreeLookState.tick(mc);
        } catch (Throwable t) {
            if (!tickErr) { tickErr = true; LOG.error("tick failed", t); }
        }
    }
}
