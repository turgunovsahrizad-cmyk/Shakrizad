package com.vekerman.visual.mixin;

import com.vekerman.visual.ZoomState;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    // Raw CallbackInfoReturnable: works whether getFov returns float or double in this version.
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void vv$fov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable cir) {
        if (!changingFov) return;
        float m = ZoomState.update();
        if (m <= 1.0005f) return;
        Object v = cir.getReturnValue();
        if (v instanceof Float f) cir.setReturnValue(f / m);
        else if (v instanceof Double d) cir.setReturnValue(d / m);
    }
}
