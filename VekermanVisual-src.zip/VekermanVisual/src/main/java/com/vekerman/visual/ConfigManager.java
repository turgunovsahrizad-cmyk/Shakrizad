package com.vekerman.visual;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Profiles live in <gameDir>/VekermanVisual/configs/<name>.json (folders are created on first launch). */
public final class ConfigManager {
    public static Path root, configs;
    private static JsonObject defaults;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {}

    public static void init() {
        Modules.init();
        root = FabricLoader.getInstance().getGameDir().resolve("VekermanVisual");
        configs = root.resolve("configs");
        try { Files.createDirectories(configs); } catch (IOException e) { VekermanVisual.LOG.warn("cannot create config dir", e); }
        defaults = snapshot();
        Path cur = root.resolve("current.json");
        if (Files.exists(cur)) readInto(cur);
        Modules.Waypoints.loadFile();
    }

    public static JsonObject snapshot() {
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);
        JsonObject mods = new JsonObject();
        for (Module m : Modules.ALL) mods.add(m.id, m.save());
        root.add("modules", mods);
        return root;
    }

    private static void apply(JsonObject root) {
        if (!root.has("modules")) return;
        JsonObject mods = root.getAsJsonObject("modules");
        for (Module m : Modules.ALL) {
            try { if (mods.has(m.id)) m.load(mods.getAsJsonObject(m.id)); }
            catch (Exception e) { VekermanVisual.LOG.warn("bad config entry {}", m.id); }
        }
    }

    private static boolean readInto(Path p) {
        try { apply(JsonParser.parseString(Files.readString(p)).getAsJsonObject()); return true; }
        catch (Exception e) { VekermanVisual.LOG.warn("cannot read {}", p, e); return false; }
    }

    public static void saveCurrent() {
        try { Files.writeString(root.resolve("current.json"), GSON.toJson(snapshot())); }
        catch (Exception e) { VekermanVisual.LOG.warn("cannot save current config", e); }
    }

    public static String clean(String name) {
        String s = name.trim().replaceAll("[^A-Za-z0-9 _.\\-]", "_");
        return s.length() > 32 ? s.substring(0, 32) : s;
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(configs)) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5)).sorted(String.CASE_INSENSITIVE_ORDER).forEach(out::add);
        } catch (Exception ignored) {}
        return out;
    }

    public static boolean save(String name) {
        name = clean(name);
        if (name.isEmpty()) return false;
        try { Files.writeString(configs.resolve(name + ".json"), GSON.toJson(snapshot())); saveCurrent(); return true; }
        catch (Exception e) { VekermanVisual.LOG.warn("save failed", e); return false; }
    }

    public static boolean load(String name) {
        Path p = configs.resolve(clean(name) + ".json");
        if (!Files.exists(p)) return false;
        boolean ok = readInto(p);
        if (ok) saveCurrent();
        return ok;
    }

    public static boolean delete(String name) {
        try { return Files.deleteIfExists(configs.resolve(clean(name) + ".json")); }
        catch (Exception e) { return false; }
    }

    public static void resetAll() {
        apply(defaults);
        for (Module m : Modules.ALL) for (Setting s : m.settings) s.reset();
        apply(defaults);
        saveCurrent();
    }
}
