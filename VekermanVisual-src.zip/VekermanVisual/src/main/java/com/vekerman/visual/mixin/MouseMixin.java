package com.vekerman.visual.mixin;

import com.vekerman.visual.ZoomState;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true, require = 0)
    private void vv$scroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (ZoomState.onScroll(vertical)) ci.cancel();
    }
}
