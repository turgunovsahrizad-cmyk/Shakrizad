package com.vekerman.visual;

import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public class Module {
    public enum Category {
        COMBAT("Combat"), MOVEMENT("Movement"), VISUAL("Visual"), HUD("HUD"), UTILITIES("Utilities"), CONFIG("Config");
        public final String label;
        Category(String l) { label = l; }
    }

    public record Action(String label, Runnable run) {}

    public final String id, name, desc;
    public final Category cat;
    public boolean enabled;
    public int bind = -1;
    public boolean hold;
    boolean active;
    boolean bindDown;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String id, String name, String desc, Category cat) {
        this.id = id; this.name = name; this.desc = desc; this.cat = cat;
    }

    public <T extends Setting> T add(T s) { settings.add(s); return s; }

    public void toggle() { enabled = !enabled; }

    public void onEnable(MinecraftClient mc) {}
    public void onDisable(MinecraftClient mc) {}
    public void onTick(MinecraftClient mc) {}
    public void onBind(MinecraftClient mc) { toggle(); }
    public List<Action> actions() { return List.of(); }

    public void sync(MinecraftClient mc) {
        try {
            if (enabled && !active) { active = true; onEnable(mc); }
            else if (!enabled && active) { active = false; onDisable(mc); }
        } catch (Throwable t) {
            VekermanVisual.LOG.warn("Module {} hook failed", id, t);
        }
    }

    public JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", enabled);
        o.addProperty("bind", bind);
        JsonObject s = new JsonObject();
        for (Setting st : settings) s.add(st.name, st.toJson());
        o.add("settings", s);
        return o;
    }

    public void load(JsonObject o) {
        if (o.has("enabled")) enabled = o.get("enabled").getAsBoolean();
        if (o.has("bind")) bind = o.get("bind").getAsInt();
        JsonObject s = o.has("settings") ? o.getAsJsonObject("settings") : null;
        if (s != null) for (Setting st : settings) if (s.has(st.name)) st.fromJson(s.get(st.name));
    }
}
