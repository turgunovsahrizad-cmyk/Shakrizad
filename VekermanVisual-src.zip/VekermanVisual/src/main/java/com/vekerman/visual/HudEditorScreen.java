package com.vekerman.visual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditorScreen extends Screen {
    private final Screen parent;
    private HudModule drag;
    private double ox, oy;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0x55000000);
        for (Module m : Modules.ALL) {
            if (m instanceof HudModule h && h.enabled) {
                h.draw(c, client, width, height);
                int x = (int) (h.x * width), y = (int) (h.y * height);
                c.drawBorder(x - 2, y - 2, (int) (h.w * h.scale.f()) + 4, (int) (h.h * h.scale.f()) + 4, h == drag ? Colors.ACCENT_L : 0x998B5CF6);
            }
        }
        c.drawCenteredTextWithShadow(textRenderer, "Drag to move  |  Scroll to resize  |  Esc to save", width / 2, 6, 0xFFFFFFFF);
    }

    private HudModule at(double mx, double my) {
        for (int i = Modules.ALL.size() - 1; i >= 0; i--) {
            Module m = Modules.ALL.get(i);
            if (m instanceof HudModule h && h.enabled && h.contains(mx, my, width, height)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        drag = at(mx, my);
        if (drag != null) { ox = mx - drag.x * width; oy = my - drag.y * height; return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != null) {
            drag.x = (float) Math.max(0, Math.min(0.98, (mx - ox) / width));
            drag.y = (float) Math.max(0, Math.min(0.98, (my - oy) / height));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) { drag = null; return super.mouseReleased(mx, my, button); }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        HudModule m = at(mx, my);
        if (m != null) { m.scale.setValue(m.scale.f() + (float) v * 0.1f); return true; }
        return false;
    }

    @Override
    public void close() {
        ConfigManager.saveCurrent();
        client.setScreen(parent);
    }
}
