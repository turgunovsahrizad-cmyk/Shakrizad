package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Recolors the red "hurt" overlay rows of the vanilla overlay texture (reflection-based, never throws). */
final class OverlayTint {
    private static Field field;
    private static Method setArgb;
    private static boolean abgr;

    static void set(MinecraftClient mc, int argb) {
        try {
            OverlayTexture ot = mc.gameRenderer.getOverlayTexture();
            if (field == null) {
                for (Field f : OverlayTexture.class.getDeclaredFields()) {
                    if (f.getType() == NativeImageBackedTexture.class) { field = f; f.setAccessible(true); break; }
                }
            }
            if (field == null) return;
            if (setArgb == null) {
                try { setArgb = NativeImage.class.getMethod("setColorArgb", int.class, int.class, int.class); }
                catch (NoSuchMethodException e) { setArgb = NativeImage.class.getMethod("setColor", int.class, int.class, int.class); abgr = true; }
            }
            NativeImageBackedTexture tex = (NativeImageBackedTexture) field.get(ot);
            NativeImage img = tex.getImage();
            if (img == null) return;
            int c = argb;
            if (abgr) c = (argb & 0xFF00FF00) | ((argb & 0xFF) << 16) | ((argb >> 16) & 0xFF);
            for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) setArgb.invoke(img, x, y, c);
            tex.upload();
        } catch (Throwable t) {
            VekermanVisual.LOG.warn("HitColor overlay failed: {}", t.toString());
        }
    }

    private OverlayTint() {}
}
