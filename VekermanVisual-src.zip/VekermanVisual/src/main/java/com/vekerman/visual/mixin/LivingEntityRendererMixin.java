package com.vekerman.visual.mixin;

import com.vekerman.visual.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
    private void vv$label(LivingEntity entity, double squaredDistance, CallbackInfoReturnable<Boolean> cir) {
        if (Modules.NAMETAG != null && Modules.NAMETAG.enabled && entity instanceof PlayerEntity p
                && p != MinecraftClient.getInstance().player && !p.isInvisible()) {
            cir.setReturnValue(true);
        }
    }
}
