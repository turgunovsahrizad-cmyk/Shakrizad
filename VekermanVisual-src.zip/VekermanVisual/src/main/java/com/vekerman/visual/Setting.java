package com.vekerman.visual;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Locale;

public class Setting {
    public enum Type { SLIDER, BOOL, CHOICE }

    public final Type type;
    public final String name;
    public float min, max, step, value;
    public boolean on;
    public int index;
    public String[] options = new String[0];
    private float defValue;
    private boolean defOn;
    private int defIndex;

    private Setting(Type t, String n) { type = t; name = n; }

    public static Setting slider(String n, float min, float max, float def, float step) {
        Setting s = new Setting(Type.SLIDER, n);
        s.min = min; s.max = max; s.step = step; s.value = def; s.defValue = def;
        return s;
    }

    public static Setting bool(String n, boolean def) {
        Setting s = new Setting(Type.BOOL, n);
        s.on = def; s.defOn = def;
        return s;
    }

    public static Setting choice(String n, int def, String... opts) {
        Setting s = new Setting(Type.CHOICE, n);
        s.options = opts; s.index = def; s.defIndex = def;
        return s;
    }

    public float f() { return value; }
    public int i() { return type == Type.CHOICE ? index : Math.round(value); }
    public boolean b() { return on; }

    public void reset() { value = defValue; on = defOn; index = defIndex; }

    public float fraction() { return (value - min) / (max - min); }

    public void setFraction(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float v = min + (max - min) * t;
        if (step > 0) v = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public void setValue(float v) { value = Math.max(min, Math.min(max, v)); }

    public void cycle() { if (options.length > 0) index = (index + 1) % options.length; }

    public String display() {
        switch (type) {
            case SLIDER:
                return step >= 1f ? String.valueOf(Math.round(value)) : String.format(Locale.ROOT, "%.2f", value);
            case BOOL:
                return on ? "On" : "Off";
            default:
                return options[index];
        }
    }

    public JsonElement toJson() {
        switch (type) {
            case SLIDER: return new JsonPrimitive(value);
            case BOOL: return new JsonPrimitive(on);
            default: return new JsonPrimitive(options[index]);
        }
    }

    public void fromJson(JsonElement e) {
        try {
            switch (type) {
                case SLIDER: setValue(e.getAsFloat()); break;
                case BOOL: on = e.getAsBoolean(); break;
                default:
                    String s = e.getAsString();
                    for (int i = 0; i < options.length; i++) if (options[i].equals(s)) index = i;
            }
        } catch (Exception ignored) {}
    }
}
