package com.vekerman.visual;

public final class Colors {
    public static final String[] NAMES = {"White", "Purple", "Cyan", "Green", "Yellow", "Red", "Pink", "Orange"};
    public static final int[] RGB = {0xFFFFFF, 0x8B5CF6, 0x22D3EE, 0x4ADE80, 0xFACC15, 0xF87171, 0xF472B6, 0xFB923C};
    public static final int BG = 0xFF0F0F12, CARD = 0xFF1A1A1E, BORDER = 0xFF2A2A31, TAB = 0xFF18181C;
    public static final int ACCENT = 0xFF8B5CF6, ACCENT_L = 0xFFC4B5FD, TEXT = 0xFFFFFFFF, SUB = 0xFFA1A1AA, OFF = 0xFF3F3F46;

    private Colors() {}
}
