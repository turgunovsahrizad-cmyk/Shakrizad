package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

public final class FreeLookState {
    public static boolean active;
    public static float yaw, pitch;

    private FreeLookState() {}

    public static void tick(MinecraftClient mc) {
        Modules.FreeLook m = Modules.FREELOOK;
        boolean want = m != null && m.enabled && m.bind >= 0 && mc.currentScreen == null && mc.player != null
                && InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.bind);
        if (want && !active) { active = true; yaw = mc.player.getYaw(); pitch = mc.player.getPitch(); }
        else if (!want) active = false;
    }

    public static void rotate(double dx, double dy) {
        float s = 0.15f * Modules.FREELOOK.sens.f();
        yaw += (float) dx * s;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * s));
    }
}
