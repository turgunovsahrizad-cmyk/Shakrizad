package com.vekerman.visual.mixin;

import com.vekerman.visual.Modules;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void vv$particles(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz,
                              CallbackInfoReturnable<Particle> cir) {
        if (Modules.ParticleOpt.skip()) cir.setReturnValue(null);
    }
}
