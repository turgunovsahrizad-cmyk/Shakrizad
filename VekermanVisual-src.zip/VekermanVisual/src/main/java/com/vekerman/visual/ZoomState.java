package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

/** Zoomify-style zoom: smooth in/out (frame-time based), wheel changes strength while held. */
public final class ZoomState {
    private static float cur = 1f;
    private static long last = System.nanoTime();

    private ZoomState() {}

    public static boolean isHeld(MinecraftClient mc) {
        Modules.Zoom z = Modules.ZOOM;
        return z != null && z.enabled && z.bind >= 0 && mc.currentScreen == null && mc.player != null
                && InputUtil.isKeyPressed(mc.getWindow().getHandle(), z.bind);
    }

    /** Call once per frame; returns the current FOV divisor (1 = no zoom). */
    public static float update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        Modules.Zoom z = Modules.ZOOM;
        if (z == null) return 1f;
        float target = isHeld(mc) ? z.strength.f() : 1f;
        cur += (target - cur) * (1f - (float) Math.exp(-z.smooth.f() * dt));
        if (Math.abs(cur - target) < 0.002f) cur = target;
        return cur;
    }

    public static float multiplier() { return cur; }

    /** Mouse sensitivity factor so aiming stays controllable while zoomed. */
    public static float sensitivityFactor() { return cur > 1.01f ? Math.max(0.1f, 1f / cur) : 1f; }

    public static boolean onScroll(double vertical) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!isHeld(mc)) return false;
        Setting s = Modules.ZOOM.strength;
        s.setValue(s.f() * (float) Math.pow(1.12, vertical));
        return true;
    }
}
