package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayDeque;

public final class ClickTracker {
    private static final ArrayDeque<Long> L = new ArrayDeque<>();
    private static boolean prev;

    private ClickTracker() {}

    public static void update(MinecraftClient mc) {
        boolean d = mc.mouse.wasLeftButtonClicked();
        long now = System.currentTimeMillis();
        if (d && !prev) L.add(now);
        prev = d;
        while (!L.isEmpty() && now - L.peekFirst() > 1000) L.pollFirst();
    }

    public static int cps() { return L.size(); }
}
