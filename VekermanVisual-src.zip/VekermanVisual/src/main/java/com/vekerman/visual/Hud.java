package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;

public final class Hud {
    private static boolean errLogged;

    private Hud() {}

    public static void render(DrawContext c, RenderTickCounter tc) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
            ClickTracker.update(mc);
            int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();
            if (!(mc.currentScreen instanceof HudEditorScreen)) {
                for (Module m : Modules.ALL) if (m instanceof HudModule h && h.enabled) h.draw(c, mc, sw, sh);
            }
            if (Modules.WAYPOINTS.enabled) Modules.WAYPOINTS.render(c, mc, sw, sh);
            if (Modules.DAMAGE.enabled) Modules.DAMAGE.render(c, mc, sw, sh);
            HudModules.Potion.renderAlerts(c, mc, sw, sh);
        } catch (Throwable t) {
            if (!errLogged) { errLogged = true; VekermanVisual.LOG.error("HUD render failed", t); }
        }
    }

    /** Projects a world position to GUI-scaled screen coordinates, or null if behind the camera. */
    public static float[] project(MinecraftClient mc, double x, double y, double z, int sw, int sh) {
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d p = cam.getPos();
        double dx = x - p.x, dy = y - p.y, dz = z - p.z;
        double yr = Math.toRadians(cam.getYaw()), pr = Math.toRadians(cam.getPitch());
        double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr), rz = -Math.sin(yr);
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.05) return null;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double fov = mc.options.getFov().getValue() / Math.max(1f, ZoomState.multiplier());
        double tan = Math.tan(Math.toRadians(fov) / 2.0);
        double aspect = (double) sw / sh;
        float sx = (float) (sw / 2.0 * (1 + xc / (zc * tan * aspect)));
        float sy = (float) (sh / 2.0 * (1 - yc / (zc * tan)));
        if (sx < -50 || sx > sw + 50 || sy < -50 || sy > sh + 50) return null;
        return new float[]{sx, sy};
    }

    public static void centeredText(DrawContext c, MinecraftClient mc, String s, float x, float y, int color, float scale) {
        var ms = c.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(scale, scale, 1f);
        c.drawCenteredTextWithShadow(mc.textRenderer, s, 0, 0, color);
        ms.pop();
    }
}
