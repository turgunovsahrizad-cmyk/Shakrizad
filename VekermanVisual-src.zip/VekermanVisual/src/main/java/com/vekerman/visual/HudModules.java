package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.*;

public final class HudModules {
    private HudModules() {}

    public static final class Fps extends HudModule {
        Fps() { super("fps", "FPS", "Show FPS counter", 0.012f, 0.02f); enabled = true; }
        @Override public void render(DrawContext c, MinecraftClient mc) {
            String t = "FPS: " + mc.getCurrentFps();
            c.drawText(mc.textRenderer, t, 0, 0, col(), true);
            w = mc.textRenderer.getWidth(t); h = 9;
        }
    }

    public static final class Cps extends HudModule {
        Cps() { super("cps", "CPS", "Show CPS counter", 0.012f, 0.07f); enabled = true; }
        @Override public void render(DrawContext c, MinecraftClient mc) {
            String t = "CPS: " + ClickTracker.cps();
            c.drawText(mc.textRenderer, t, 0, 0, col(), true);
            w = mc.textRenderer.getWidth(t); h = 9;
        }
    }

    public static final class Ping extends HudModule {
        Ping() { super("ping", "Ping", "Show ping", 0.012f, 0.12f); enabled = true; }
        @Override public void render(DrawContext c, MinecraftClient mc) {
            String v = "-";
            try {
                PlayerListEntry e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) v = e.getLatency() + " ms";
            } catch (Throwable ignored) {}
            String t = "Ping: " + v;
            c.drawText(mc.textRenderer, t, 0, 0, col(), true);
            w = mc.textRenderer.getWidth(t); h = 9;
        }
    }

    public static final class Coords extends HudModule {
        Coords() { super("coords", "Coordinates", "Show XYZ coordinates", 0.012f, 0.17f); enabled = true; }
        @Override public void render(DrawContext c, MinecraftClient mc) {
            String t = "XYZ: " + (int) Math.floor(mc.player.getX()) + " / " + (int) Math.floor(mc.player.getY()) + " / " + (int) Math.floor(mc.player.getZ());
            c.drawText(mc.textRenderer, t, 0, 0, col(), true);
            w = mc.textRenderer.getWidth(t); h = 9;
        }
    }

    public static final class Keys extends HudModule {
        Keys() { super("keystrokes", "Keystrokes", "Show pressed keys", 0.012f, 0.50f); enabled = true; }

        private void cell(DrawContext c, MinecraftClient mc, String label, int x, int y, int cw, int ch, boolean down) {
            int base = col();
            int border = down ? Colors.ACCENT : ((base & 0x00FFFFFF) | 0x88000000);
            c.drawBorder(x, y, cw, ch, border);
            c.drawCenteredTextWithShadow(mc.textRenderer, label, x + cw / 2, y + (ch - 8) / 2, down ? Colors.ACCENT_L : base);
        }

        @Override public void render(DrawContext c, MinecraftClient mc) {
            var o = mc.options;
            cell(c, mc, "W", 20, 0, 18, 18, o.forwardKey.isPressed());
            cell(c, mc, "A", 0, 20, 18, 18, o.leftKey.isPressed());
            cell(c, mc, "S", 20, 20, 18, 18, o.backKey.isPressed());
            cell(c, mc, "D", 40, 20, 18, 18, o.rightKey.isPressed());
            cell(c, mc, "LMB", 0, 40, 28, 16, o.attackKey.isPressed());
            cell(c, mc, "RMB", 30, 40, 28, 16, o.useKey.isPressed());
            cell(c, mc, "---", 0, 58, 58, 12, o.jumpKey.isPressed());
            w = 58; h = 70;
        }
    }

    public static final class Armor extends HudModule {
        final Setting layout = add(Setting.choice("Layout", 0, "Vertical", "Horizontal"));
        static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

        Armor() { super("armor", "Armor HUD", "Show armor with durability % (Vertical / Horizontal)", 0.90f, 0.45f); enabled = true; }

        @Override public void render(DrawContext c, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            boolean vert = layout.i() == 0;
            int n = 0, maxW = 0;
            for (EquipmentSlot s : SLOTS) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (st.isEmpty()) continue;
                String pct = st.isDamageable() ? (100 * (st.getMaxDamage() - st.getDamage()) / st.getMaxDamage()) + "%" : "";
                if (vert) {
                    int y = n * 18;
                    c.drawItem(st, 0, y);
                    if (!pct.isEmpty()) c.drawText(tr, pct, 20, y + 4, col(), true);
                    maxW = Math.max(maxW, 20 + tr.getWidth(pct));
                } else {
                    int x = n * 30;
                    c.drawItem(st, x + 6, 0);
                    c.drawCenteredTextWithShadow(tr, pct, x + 14, 18, col());
                    maxW = x + 28;
                }
                n++;
            }
            if (n == 0) {
                c.drawText(tr, "Armor HUD", 0, 0, 0x88FFFFFF, true);
                w = tr.getWidth("Armor HUD"); h = 9;
            } else { w = maxW; h = vert ? n * 18 : 30; }
        }
    }

    public static final class Potion extends HudModule {
        final Setting layout = add(Setting.choice("Layout", 0, "Vertical", "Horizontal"));
        final Setting alertSize = add(Setting.slider("Alert Icon Size", 12, 48, 24, 1));
        final Setting sound = add(Setting.bool("Alert Sound", true));
        final Setting volume = add(Setting.slider("Alert Volume", 0f, 1f, 0.4f, 0.05f));

        record Alert(Identifier icon, long start) {}
        static final List<Alert> ALERTS = new ArrayList<>();
        Map<RegistryEntry<StatusEffect>, Integer> last = new HashMap<>();

        Potion() { super("potion", "Potion HUD", "Show active effects with time (Vertical / Horizontal)", 0.88f, 0.02f); enabled = true; }

        static Identifier iconOf(RegistryEntry<StatusEffect> e) {
            return e.getKey().map(k -> k.getValue().withPrefixedPath("mob_effect/")).orElse(null);
        }

        static String time(StatusEffectInstance i) {
            if (i.getDuration() < 0) return "**:**";
            int s = i.getDuration() / 20;
            return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
        }

        @Override public void render(DrawContext c, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            boolean vert = layout.i() == 0;
            int n = 0, maxW = 0;
            for (StatusEffectInstance i : mc.player.getStatusEffects()) {
                if (!i.shouldShowIcon()) continue;
                Identifier id = iconOf(i.getEffectType());
                if (vert) {
                    int y = n * 18;
                    if (id != null) c.drawGuiTexture(RenderLayer::getGuiTextured, id, 0, y, 16, 16);
                    String nm = i.getEffectType().value().getName().getString() + (i.getAmplifier() > 0 ? " " + (i.getAmplifier() + 1) : "");
                    String t = nm + "  " + time(i);
                    c.drawText(tr, t, 19, y + 4, col(), true);
                    maxW = Math.max(maxW, 19 + tr.getWidth(t));
                } else {
                    int x = n * 32;
                    if (id != null) c.drawGuiTexture(RenderLayer::getGuiTextured, id, x + 7, 0, 16, 16);
                    c.drawCenteredTextWithShadow(tr, time(i), x + 15, 18, col());
                    maxW = x + 30;
                }
                n++;
            }
            if (n == 0) {
                c.drawText(tr, "Potion HUD", 0, 0, 0x88FFFFFF, true);
                w = tr.getWidth("Potion HUD"); h = 9;
            } else { w = maxW; h = vert ? n * 18 : 30; }
        }

        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null) { last.clear(); return; }
            Map<RegistryEntry<StatusEffect>, Integer> cur = new HashMap<>();
            for (StatusEffectInstance i : mc.player.getStatusEffects()) {
                if (i.shouldShowIcon() && i.getDuration() >= 0) cur.put(i.getEffectType(), i.getDuration());
            }
            for (Map.Entry<RegistryEntry<StatusEffect>, Integer> e : last.entrySet()) {
                if (!cur.containsKey(e.getKey()) && e.getValue() <= 25) {
                    Identifier id = iconOf(e.getKey());
                    if (id != null) trigger(mc, id);
                }
            }
            last = cur;
        }

        void trigger(MinecraftClient mc, Identifier id) {
            ALERTS.add(new Alert(id, System.currentTimeMillis()));
            if (sound.b() && volume.f() > 0.001f) {
                mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.4f, volume.f()));
            }
        }

        /** Icon under the crosshair: blinks ~2 s, then fades out (2.5 s total). */
        public static void renderAlerts(DrawContext c, MinecraftClient mc, int sw, int sh) {
            if (ALERTS.isEmpty()) return;
            long now = System.currentTimeMillis();
            ALERTS.removeIf(a -> now - a.start > 2500);
            int size = Modules.POTION != null ? Modules.POTION.alertSize.i() : 24;
            int total = ALERTS.size() * (size + 4) - 4;
            int x = sw / 2 - total / 2;
            int y = sh / 2 + 14;
            for (Alert a : ALERTS) {
                float el = now - a.start;
                float t = el / 2500f;
                float fade = t < 0.7f ? 1f : 1f - (t - 0.7f) / 0.3f;
                float blink = t < 0.7f ? 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(el / 1000f * Math.PI * 5)) : 1f;
                int alpha = Math.max(0, Math.min(255, (int) (255 * fade * blink)));
                c.drawGuiTexture(RenderLayer::getGuiTextured, a.icon, x, y, size, size, (alpha << 24) | 0xFFFFFF);
                x += size + 4;
            }
        }
    }
}
