package com.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;

public class ClickGuiScreen extends Screen {
    private static class Hit {
        int x1, y1, x2, y2, bx, bw;
        boolean clip;
        Runnable click;
        DoubleConsumer drag;
        boolean contains(double mx, double my, int top, int bot) {
            if (clip && (my < top || my > bot)) return false;
            return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
        }
    }

    private final Screen parent;
    private Module.Category tab = Module.Category.VISUAL;
    private Module open;
    private boolean keybinds;
    private float scroll, maxScroll;
    private TextFieldWidget search, nameField;
    private boolean adding;
    private final List<Hit> hits = new ArrayList<>();
    private Hit pressed;
    private double pressX, pressY;
    private boolean moved;
    private Module listenMod;
    private String status = "";
    private long statusT;
    private String confirm = "";
    private int wx, wy, ww, wh, cLeft, cRight, cTop, cBot, R;

    public ClickGuiScreen(Screen parent) {
        super(Text.literal("VekermanVisual"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ww = Math.min(width - 6, 470);
        wh = Math.min(height - 6, 300);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2;
        R = Math.max(6, ww / 42);
        cLeft = wx + 14; cRight = wx + ww - 14; cTop = wy + 40; cBot = wy + wh - 34;
        String old = search == null ? "" : search.getText();
        int sw = Math.min(170, ww / 3);
        search = new TextFieldWidget(textRenderer, wx + ww - sw - 4, wy + 13, sw - 20, 14, Text.literal("Search"));
        search.setDrawsBackground(false);
        search.setPlaceholder(Text.literal("Search modules..."));
        search.setText(old);
        search.setChangedListener(s -> scroll = 0);
        addDrawableChild(search);
        nameField = new TextFieldWidget(textRenderer, cLeft + 10, cTop + 4, ww - 150, 14, Text.literal("Name"));
        nameField.setDrawsBackground(false);
        nameField.setMaxLength(24);
        nameField.setPlaceholder(Text.literal("Config name..."));
        nameField.visible = false;
        addDrawableChild(nameField);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        ConfigManager.saveCurrent();
        client.setScreen(parent);
    }

    // ------------------------------------------------------------ drawing helpers

    static void rr(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int in = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - d * d)));
            c.fill(x + in, y + i, x + w - in, y + i + 1, col);
            c.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, col);
        }
        c.fill(x, y + r, x + w, y + h - r, col);
    }

    private void text(DrawContext c, String s, int x, int y, int col, float scale, boolean bold) {
        var ms = c.getMatrices();
        ms.push();
        ms.scale(scale, scale, 1f);
        Text t = bold ? Text.literal(s).formatted(Formatting.BOLD) : Text.literal(s);
        c.drawText(textRenderer, t, Math.round(x / scale), Math.round(y / scale), col, false);
        ms.pop();
    }

    private void diamond(DrawContext c, int cx, int cy, int r, int col) {
        for (int i = -r; i <= r; i++) {
            int half = r - Math.abs(i);
            c.fill(cx - half, cy + i, cx + half + 1, cy + i + 1, col);
        }
    }

    private void gear(DrawContext c, int x, int y, int col) {
        String[] p = {"..###..", ".#####.", "###.###", "##...##", "###.###", ".#####.", "..###.."};
        for (int j = 0; j < p.length; j++) for (int i = 0; i < p[j].length(); i++) if (p[j].charAt(i) == '#') c.fill(x + i, y + j, x + i + 1, y + j + 1, col);
        c.fill(x + 3, y - 1, x + 4, y, col); c.fill(x + 3, y + 7, x + 4, y + 8, col);
        c.fill(x - 1, y + 3, x, y + 4, col); c.fill(x + 7, y + 3, x + 8, y + 4, col);
    }

    private void toggle(DrawContext c, int x, int y, boolean on) {
        rr(c, x, y, 22, 12, 6, on ? Colors.ACCENT : Colors.OFF);
        rr(c, on ? x + 11 : x + 1, y + 1, 10, 10, 5, on ? 0xFFEDE9FE : 0xFF9CA3AF);
    }

    private Hit hit(int x, int y, int w, int h, Runnable click, boolean clip) {
        Hit t = new Hit();
        t.x1 = x; t.y1 = y; t.x2 = x + w; t.y2 = y + h; t.click = click; t.clip = clip;
        hits.add(t);
        return t;
    }

    private void btn(DrawContext c, String label, int x, int y, int w, int h, boolean accent, Runnable click, boolean clip) {
        rr(c, x, y, w, h, Math.min(6, h / 2), accent ? Colors.ACCENT : Colors.CARD);
        c.drawCenteredTextWithShadow(textRenderer, label, x + w / 2, y + (h - 8) / 2, Colors.TEXT);
        hit(x, y, w, h, click, clip);
    }

    private String keyName(int k) {
        if (k < 0) return "None";
        try { return InputUtil.fromKeyCode(k, 0).getLocalizedText().getString(); } catch (Throwable t) { return "Key " + k; }
    }

    private void say(String s) { status = s; statusT = System.currentTimeMillis(); }

    // ------------------------------------------------------------------ render

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        hits.clear();
        c.fill(0, 0, width, height, 0x99000000);
        rr(c, wx - 1, wy - 1, ww + 2, wh + 2, R + 1, Colors.BORDER);
        rr(c, wx, wy, ww, wh, R, Colors.BG);

        // header
        diamond(c, wx + 20, wy + 20, 3, Colors.ACCENT);
        diamond(c, wx + 14, wy + 14, 3, 0xFFA78BFA);
        diamond(c, wx + 26, wy + 14, 3, 0xFFA78BFA);
        diamond(c, wx + 20, wy + 26, 3, 0xFF7C3AED);
        text(c, "VekermanVisual", wx + 36, wy + 12, Colors.TEXT, 1.4f, true);
        int sw = Math.min(170, ww / 3);
        rr(c, wx + ww - sw - 14, wy + 8, sw, 22, 8, Colors.BORDER);
        rr(c, wx + ww - sw - 13, wy + 9, sw - 2, 20, 8, Colors.CARD);

        // content
        c.enableScissor(cLeft - 2, cTop, cRight + 2, cBot);
        int endY;
        if (open != null) endY = drawSettings(c, open);
        else if (keybinds) endY = drawKeybinds(c);
        else if (!search.getText().trim().isEmpty()) endY = drawGrid(c, matching(), cTop - (int) scroll);
        else if (tab == Module.Category.CONFIG) endY = drawConfig(c);
        else if (tab == Module.Category.HUD) {
            int y = cTop - (int) scroll;
            btn(c, "Edit HUD Layout  (drag elements, scroll to resize)", cLeft, y, cRight - cLeft, 20, true, () -> client.setScreen(new HudEditorScreen(this)), true);
            endY = drawGrid(c, Modules.of(tab), y + 28);
        } else endY = drawGrid(c, Modules.of(tab), cTop - (int) scroll);
        c.disableScissor();
        maxScroll = Math.max(0, endY + (int) scroll - cBot);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        if (nameField != null && !(tab == Module.Category.CONFIG && open == null && !keybinds)) nameField.visible = false;

        // tabs
        Module.Category[] cats = Module.Category.values();
        int total = 0;
        int[] tw = new int[cats.length];
        for (int i = 0; i < cats.length; i++) { tw[i] = textRenderer.getWidth(cats[i].label) + 16; total += tw[i] + 4; }
        total -= 4;
        int x = wx + (ww - total) / 2, ty = wy + wh - 26;
        for (int i = 0; i < cats.length; i++) {
            final Module.Category cat = cats[i];
            boolean act = cat == tab && search.getText().isEmpty();
            rr(c, x, ty, tw[i], 18, 9, act ? Colors.ACCENT : Colors.BORDER);
            if (!act) rr(c, x + 1, ty + 1, tw[i] - 2, 16, 8, Colors.TAB);
            c.drawCenteredTextWithShadow(textRenderer, cat.label, x + tw[i] / 2, ty + 5, Colors.TEXT);
            hit(x, ty, tw[i], 18, () -> { tab = cat; open = null; keybinds = false; adding = false; scroll = 0; search.setText(""); }, false);
            x += tw[i] + 4;
        }
        if (System.currentTimeMillis() - statusT < 2500 && !status.isEmpty()) {
            c.drawCenteredTextWithShadow(textRenderer, status, wx + ww / 2, wy + wh - 38, Colors.ACCENT_L);
        }
    }

    private List<Module> matching() {
        String q = search.getText().trim().toLowerCase();
        List<Module> l = new ArrayList<>();
        for (Module m : Modules.ALL) if (m.name.toLowerCase().contains(q) || m.desc.toLowerCase().contains(q)) l.add(m);
        return l;
    }

    private int drawGrid(DrawContext c, List<Module> list, int y0) {
        int gap = 8, cw = (cRight - cLeft - gap) / 2, ch = 38;
        int y = y0;
        for (int i = 0; i < list.size(); i++) {
            int x = cLeft + (i % 2) * (cw + gap);
            if (i % 2 == 0 && i > 0) y += ch + gap;
            card(c, list.get(i), x, y, cw, ch);
        }
        return y + ch + gap;
    }

    private void card(DrawContext c, Module m, int x, int y, int w, int h) {
        rr(c, x, y, w, h, 8, Colors.BORDER);
        rr(c, x + 1, y + 1, w - 2, h - 2, 7, Colors.CARD);
        text(c, m.name, x + 8, y + 6, Colors.TEXT, 1.0f, true);
        int tw = w - 62;
        List<OrderedText> lines = textRenderer.wrapLines(StringVisitable.plain(m.desc), (int) (tw / 0.75f));
        var ms = c.getMatrices();
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            ms.push();
            ms.scale(0.75f, 0.75f, 1f);
            c.drawText(textRenderer, lines.get(i), Math.round((x + 8) / 0.75f), Math.round((y + 19 + i * 8) / 0.75f), Colors.SUB, false);
            ms.pop();
        }
        int gx = x + w - 46, ty = y + h / 2 - 6;
        gear(c, gx, y + h / 2 - 3, Colors.SUB);
        toggle(c, x + w - 30, ty, m.enabled);
        hit(x, y, w, h, m::toggle, true);
        hit(gx - 4, y, 16, h, () -> { open = m; scroll = 0; }, true);
        hit(x + w - 32, y, 32, h, m::toggle, true);
    }

    private int drawSettings(DrawContext c, Module m) {
        int y = cTop - (int) scroll;
        btn(c, "< Back", cLeft, y, 50, 16, false, () -> { open = null; scroll = 0; }, true);
        text(c, m.name, cLeft + 58, y + 3, Colors.TEXT, 1.1f, true);
        toggle(c, cRight - 24, y + 2, m.enabled);
        hit(cRight - 26, y, 26, 16, m::toggle, true);
        y += 24;
        int rw = cRight - cLeft;
        for (Setting s : m.settings) {
            switch (s.type) {
                case BOOL -> {
                    rr(c, cLeft, y, rw, 22, 6, Colors.CARD);
                    c.drawText(textRenderer, s.name, cLeft + 8, y + 7, Colors.TEXT, false);
                    toggle(c, cRight - 30, y + 5, s.on);
                    hit(cLeft, y, rw, 22, () -> s.on = !s.on, true);
                    y += 26;
                }
                case CHOICE -> {
                    rr(c, cLeft, y, rw, 22, 6, Colors.CARD);
                    c.drawText(textRenderer, s.name, cLeft + 8, y + 7, Colors.TEXT, false);
                    String v = "< " + s.options[s.index] + " >";
                    c.drawText(textRenderer, v, cRight - 8 - textRenderer.getWidth(v), y + 7, Colors.ACCENT_L, false);
                    hit(cLeft, y, rw, 22, s::cycle, true);
                    y += 26;
                }
                default -> {
                    rr(c, cLeft, y, rw, 30, 6, Colors.CARD);
                    c.drawText(textRenderer, s.name, cLeft + 8, y + 5, Colors.TEXT, false);
                    String v = s.display();
                    c.drawText(textRenderer, v, cRight - 8 - textRenderer.getWidth(v), y + 5, Colors.ACCENT_L, false);
                    int bx = cLeft + 10, bw = rw - 20, by = y + 20;
                    rr(c, bx, by, bw, 4, 2, Colors.OFF);
                    int fw = Math.max(4, (int) (bw * s.fraction()));
                    rr(c, bx, by, fw, 4, 2, Colors.ACCENT);
                    rr(c, bx + fw - 4, by - 2, 8, 8, 4, 0xFFEDE9FE);
                    Hit h = hit(cLeft, y, rw, 30, null, true);
                    h.bx = bx; h.bw = bw;
                    h.drag = f -> s.setFraction((float) f);
                    y += 34;
                }
            }
        }
        // keybind
        rr(c, cLeft, y, rw, 22, 6, Colors.CARD);
        c.drawText(textRenderer, m.hold ? "Hold Key" : (m.id.equals("waypoints") ? "Add Waypoint Key" : "Toggle Key"), cLeft + 8, y + 7, Colors.TEXT, false);
        String kv = listenMod == m ? "Press a key..." : keyName(m.bind);
        rr(c, cRight - 90, y + 3, 84, 16, 5, listenMod == m ? Colors.ACCENT : Colors.BORDER);
        c.drawCenteredTextWithShadow(textRenderer, kv, cRight - 48, y + 7, Colors.TEXT);
        hit(cRight - 90, y + 3, 84, 16, () -> listenMod = m, true);
        y += 28;
        for (Module.Action a : m.actions()) {
            btn(c, a.label(), cLeft, y, rw, 18, false, a.run(), true);
            y += 22;
        }
        return y + 6;
    }

    private int drawKeybinds(DrawContext c) {
        int y = cTop - (int) scroll;
        btn(c, "< Back", cLeft, y, 50, 16, false, () -> { keybinds = false; scroll = 0; }, true);
        text(c, "Keybind Manager", cLeft + 58, y + 3, Colors.TEXT, 1.1f, true);
        y += 24;
        int rw = cRight - cLeft;
        rr(c, cLeft, y, rw, 22, 6, Colors.CARD);
        c.drawText(textRenderer, "Open Menu (also: pause screen button)", cLeft + 8, y + 7, Colors.TEXT, false);
        c.drawText(textRenderer, "Right Shift", cRight - 8 - textRenderer.getWidth("Right Shift"), y + 7, Colors.SUB, false);
        y += 26;
        for (Module m : Modules.ALL) {
            rr(c, cLeft, y, rw, 22, 6, Colors.CARD);
            c.drawText(textRenderer, m.name + (m.hold ? " (hold)" : ""), cLeft + 8, y + 7, Colors.TEXT, false);
            String kv = listenMod == m ? "Press a key..." : keyName(m.bind);
            rr(c, cRight - 90, y + 3, 84, 16, 5, listenMod == m ? Colors.ACCENT : Colors.BORDER);
            c.drawCenteredTextWithShadow(textRenderer, kv, cRight - 48, y + 7, Colors.TEXT);
            hit(cRight - 90, y + 3, 84, 16, () -> listenMod = m, true);
            y += 26;
        }
        return y;
    }

    private int drawConfig(DrawContext c) {
        int y = cTop - (int) scroll;
        int rw = cRight - cLeft;
        text(c, "Profiles", cLeft, y, Colors.ACCENT_L, 1.0f, true);
        y += 12;
        if (adding) {
            rr(c, cLeft, y, rw - 86, 22, 6, Colors.BORDER);
            rr(c, cLeft + 1, y + 1, rw - 88, 20, 6, Colors.CARD);
            nameField.setX(cLeft + 8);
            nameField.setY(y + 5);
            nameField.setWidth(rw - 104);
            nameField.visible = y >= cTop - 2 && y + 22 <= cBot;
            btn(c, "Save", cRight - 80, y, 46, 22, true, this::saveNew, true);
            btn(c, "X", cRight - 30, y, 30, 22, false, () -> { adding = false; nameField.setText(""); }, true);
        } else {
            nameField.visible = false;
            btn(c, "+ Add Config", cLeft, y, rw, 22, true, () -> { adding = true; nameField.setText(""); nameField.setFocused(true); setFocused(nameField); }, true);
        }
        y += 28;
        List<String> names = ConfigManager.list();
        if (names.isEmpty()) {
            c.drawText(textRenderer, "No saved configs yet.", cLeft + 4, y + 2, Colors.SUB, false);
            y += 16;
        }
        for (String n : names) {
            rr(c, cLeft, y, rw, 24, 6, Colors.CARD);
            c.drawText(textRenderer, textRenderer.trimToWidth(n, rw - 160), cLeft + 8, y + 8, Colors.TEXT, false);
            boolean sure = confirm.equals(n);
            btn(c, "Load", cRight - 148, y + 3, 42, 18, false, () -> say(ConfigManager.load(n) ? "Loaded " + n : "Load failed"), true);
            btn(c, "Save", cRight - 102, y + 3, 42, 18, false, () -> say(ConfigManager.save(n) ? "Saved " + n : "Save failed"), true);
            btn(c, sure ? "Sure?" : "Delete", cRight - 56, y + 3, 52, 18, sure, () -> {
                if (sure) { ConfigManager.delete(n); confirm = ""; say("Deleted " + n); } else confirm = n;
            }, true);
            y += 28;
        }
        y += 4;
        text(c, "Tools", cLeft, y, Colors.ACCENT_L, 1.0f, true);
        y += 12;
        int half = (rw - 8) / 2;
        btn(c, "Keybind Manager", cLeft, y, half, 22, false, () -> { keybinds = true; scroll = 0; }, true);
        boolean sureReset = confirm.equals("\u0000reset");
        btn(c, sureReset ? "Sure? Click again" : "Reset All", cLeft + half + 8, y, half, 22, sureReset, () -> {
            if (sureReset) { ConfigManager.resetAll(); confirm = ""; say("All settings reset"); } else confirm = "\u0000reset";
        }, true);
        y += 32;
        text(c, "Optimization", cLeft, y, Colors.ACCENT_L, 1.0f, true);
        y += 12;
        return drawGrid(c, Modules.of(Module.Category.CONFIG), y);
    }

    private void saveNew() {
        String n = ConfigManager.clean(nameField.getText());
        if (n.isEmpty()) { say("Enter a name"); return; }
        say(ConfigManager.save(n) ? "Saved " + n : "Save failed");
        adding = false;
        nameField.setText("");
    }

    // ------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        pressX = mx; pressY = my; moved = false; pressed = null;
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (h.contains(mx, my, cTop, cBot)) {
                    pressed = h;
                    if (h.drag != null) h.drag.accept(Math.max(0, Math.min(1, (mx - h.bx) / h.bw)));
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (pressed != null && pressed.drag != null) {
            pressed.drag.accept(Math.max(0, Math.min(1, (mx - pressed.bx) / pressed.bw)));
            return true;
        }
        if (button == 0 && my >= cTop && my <= cBot) {
            if (Math.abs(my - pressY) > 4 || Math.abs(mx - pressX) > 4) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        Hit p = pressed;
        pressed = null;
        if (p != null && p.click != null && !moved) { p.click.run(); return true; }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) v * 20f));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (listenMod != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { /* cancel */ }
            else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) listenMod.bind = -1;
            else listenMod.bind = key;
            listenMod = null;
            return true;
        }
        if (adding && nameField.isFocused() && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) { saveNew(); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && !search.isFocused() && !nameField.isFocused()) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
