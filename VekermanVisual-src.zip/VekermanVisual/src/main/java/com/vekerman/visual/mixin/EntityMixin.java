package com.vekerman.visual.mixin;

import com.vekerman.visual.FreeLookState;
import com.vekerman.visual.ZoomState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void vv$look(double dx, double dy, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (FreeLookState.active) {
            FreeLookState.rotate(dx, dy);
            ci.cancel();
        }
    }

    @ModifyVariable(method = "changeLookDirection", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private double vv$sensX(double v) {
        return (Object) this == MinecraftClient.getInstance().player ? v * ZoomState.sensitivityFactor() : v;
    }

    @ModifyVariable(method = "changeLookDirection", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private double vv$sensY(double v) {
        return (Object) this == MinecraftClient.getInstance().player ? v * ZoomState.sensitivityFactor() : v;
    }
}
