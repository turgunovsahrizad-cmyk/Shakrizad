package com.vekerman.visual;

import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

public abstract class HudModule extends Module {
    public float x, y;
    public int w = 40, h = 10;
    public final Setting scale = add(Setting.slider("Scale", 0.5f, 2f, 1f, 0.05f));
    public final Setting opacity = add(Setting.slider("Opacity", 0.2f, 1f, 1f, 0.05f));
    public final Setting color = add(Setting.choice("Color", 0, Colors.NAMES));

    protected HudModule(String id, String name, String desc, float x, float y) {
        super(id, name, desc, Category.HUD);
        this.x = x; this.y = y;
    }

    public int col() {
        int a = Math.round(255 * opacity.f());
        return (a << 24) | Colors.RGB[color.i()];
    }

    /** Draw at (0,0); set w/h to the drawn size. No background by design. */
    public abstract void render(DrawContext ctx, MinecraftClient mc);

    public final void draw(DrawContext ctx, MinecraftClient mc, int sw, int sh) {
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(x * sw, y * sh, 0f);
        ms.scale(scale.f(), scale.f(), 1f);
        render(ctx, mc);
        ms.pop();
    }

    public boolean contains(double mx, double my, int sw, int sh) {
        float px = x * sw, py = y * sh;
        return mx >= px - 2 && my >= py - 2 && mx <= px + w * scale.f() + 2 && my <= py + h * scale.f() + 2;
    }

    @Override
    public JsonObject save() {
        JsonObject o = super.save();
        o.addProperty("x", x);
        o.addProperty("y", y);
        return o;
    }

    @Override
    public void load(JsonObject o) {
        super.load(o);
        if (o.has("x")) x = o.get("x").getAsFloat();
        if (o.has("y")) y = o.get("y").getAsFloat();
    }
}
