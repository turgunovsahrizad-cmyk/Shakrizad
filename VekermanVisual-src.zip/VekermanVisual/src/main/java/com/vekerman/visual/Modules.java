package com.vekerman.visual;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();

    public static HitColor HITCOLOR;
    public static Damage DAMAGE;
    public static FreeLook FREELOOK;
    public static Zoom ZOOM;
    public static NameTag NAMETAG;
    public static Waypoints WAYPOINTS;
    public static Culling CULLING;
    public static ParticleOpt PARTICLES;
    public static HudModules.Potion POTION;

    private Modules() {}

    public static void init() {
        if (!ALL.isEmpty()) return;
        // Combat
        ALL.add(HITCOLOR = new HitColor());
        ALL.add(DAMAGE = new Damage());
        // Movement
        ALL.add(new AutoSprint());
        ALL.add(FREELOOK = new FreeLook());
        // Visual
        ALL.add(ZOOM = new Zoom());
        ALL.add(new Fullbright());
        ALL.add(NAMETAG = new NameTag());
        ALL.add(new MotionBlur());
        ALL.add(WAYPOINTS = new Waypoints());
        // HUD
        ALL.add(new HudModules.Fps());
        ALL.add(new HudModules.Cps());
        ALL.add(new HudModules.Keys());
        ALL.add(new HudModules.Coords());
        ALL.add(new HudModules.Armor());
        ALL.add(POTION = new HudModules.Potion());
        ALL.add(new HudModules.Ping());
        // Utilities
        ALL.add(new ToggleSprint());
        ALL.add(new FpsBoost());
        ALL.add(CULLING = new Culling());
        // Config (optimization)
        ALL.add(new DynFps());
        ALL.add(new FastChunk());
        ALL.add(PARTICLES = new ParticleOpt());
        ALL.add(new SmoothFps());
        ALL.add(new MemoryCleaner());
    }

    public static Module byId(String id) {
        for (Module m : ALL) if (m.id.equals(id)) return m;
        return null;
    }

    public static List<Module> of(Module.Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : ALL) if (m.cat == c) l.add(m);
        return l;
    }

    // ---------------------------------------------------------------- Combat

    public static final class HitColor extends Module {
        final Setting color = add(Setting.choice("Color", 1, Colors.NAMES));
        final Setting opacity = add(Setting.slider("Opacity", 0.2f, 1f, 0.7f, 0.05f));
        int applied = 0;

        HitColor() {
            super("hitcolor", "HitColor", "Change hit entity highlight color", Category.COMBAT);
            enabled = true;
        }

        int argb() { return (Math.round(255 * opacity.f()) << 24) | Colors.RGB[color.i()]; }

        @Override public void onEnable(MinecraftClient mc) { applied = 0; }
        @Override public void onTick(MinecraftClient mc) {
            int a = argb();
            if (a != applied) { OverlayTint.set(mc, a); applied = a; }
        }
        @Override public void onDisable(MinecraftClient mc) { OverlayTint.set(mc, 0xB2FF0000); applied = 0; }
    }

    public static final class Damage extends Module {
        final Setting size = add(Setting.slider("Size", 0.6f, 2f, 1f, 0.05f));
        final Setting color = add(Setting.choice("Color", 7, Colors.NAMES));
        record Pop(double x, double y, double z, float dmg, long t) {}
        final Map<Integer, float[]> tracked = new HashMap<>();
        final List<Pop> pops = new ArrayList<>();
        long tick;

        Damage() {
            super("damage", "Damage Indicator", "Show damage numbers on hit", Category.COMBAT);
            enabled = true;
        }

        void onAttack(Entity e) {
            if (enabled && e instanceof LivingEntity le) tracked.put(e.getId(), new float[]{le.getHealth(), tick + 60});
        }

        @Override public void onTick(MinecraftClient mc) {
            tick++;
            if (mc.world == null) return;
            Iterator<Map.Entry<Integer, float[]>> it = tracked.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Integer, float[]> en = it.next();
                Entity e = mc.world.getEntityById(en.getKey());
                if (!(e instanceof LivingEntity le) || tick > en.getValue()[1]) { it.remove(); continue; }
                float hp = le.getHealth();
                if (hp < en.getValue()[0]) {
                    float d = en.getValue()[0] - hp;
                    pops.add(new Pop(e.getX() + (Math.random() - 0.5) * 0.5, e.getY() + e.getHeight() + 0.2, e.getZ() + (Math.random() - 0.5) * 0.5, d, System.currentTimeMillis()));
                }
                en.getValue()[0] = hp;
            }
        }

        void render(DrawContext c, MinecraftClient mc, int sw, int sh) {
            long now = System.currentTimeMillis();
            pops.removeIf(p -> now - p.t > 1200);
            for (Pop p : pops) {
                float age = (now - p.t) / 1000f;
                float[] s = Hud.project(mc, p.x, p.y + age * 0.5, p.z, sw, sh);
                if (s == null) continue;
                int alpha = Math.max(10, Math.min(255, (int) (255 * (1f - age / 1.2f))));
                String t = p.dmg == Math.floor(p.dmg) ? "-" + (int) p.dmg : String.format(Locale.ROOT, "-%.1f", p.dmg);
                Hud.centeredText(c, mc, t, s[0], s[1], (alpha << 24) | Colors.RGB[color.i()], size.f());
            }
        }
    }

    // -------------------------------------------------------------- Movement

    public static final class AutoSprint extends Module {
        AutoSprint() { super("autosprint", "AutoSprint", "Automatically sprint while moving", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                    && !p.isUsingItem() && !p.isSprinting() && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        }
    }

    public static final class FreeLook extends Module {
        final Setting sens = add(Setting.slider("Sensitivity", 0.2f, 2f, 1f, 0.05f));

        FreeLook() {
            super("freelook", "Free Look", "Look around without turning player", Category.MOVEMENT);
            hold = true; bind = GLFW.GLFW_KEY_LEFT_ALT; enabled = true;
        }
    }

    // ---------------------------------------------------------------- Visual

    public static final class Zoom extends Module {
        public final Setting strength = add(Setting.slider("Strength", 1.5f, 20f, 4f, 0.1f));
        public final Setting smooth = add(Setting.slider("Smoothness", 1f, 20f, 8f, 0.5f));

        Zoom() {
            super("zoom", "Zoom", "Smooth camera zoom on hold", Category.VISUAL);
            hold = true; bind = GLFW.GLFW_KEY_C; enabled = true;
        }
    }

    public static final class Fullbright extends Module {
        Fullbright() { super("fullbright", "Fullbright", "Max brightness, full lighting", Category.VISUAL); }

        @Override public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            StatusEffectInstance i = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (i == null || (!i.shouldShowIcon() && i.getDuration() < 900)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            }
        }

        @Override public void onDisable(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            StatusEffectInstance i = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (i != null && !i.shouldShowIcon()) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    public static final class NameTag extends Module {
        NameTag() { super("nametag", "Name Tag", "Always show player name tags", Category.VISUAL); }
    }

    public static final class MotionBlur extends Module {
        final Setting strength = add(Setting.slider("Strength", 0f, 1f, 0.5f, 0.05f));
        MotionBlur() { super("motionblur", "Motion Blur", "Adds motion blur effect to view", Category.VISUAL); }
        // TODO: needs a custom post-effect shader; the toggle and strength are saved but nothing is rendered yet.
    }

    public static final class Waypoints extends Module {
        public record Wp(String name, double x, double y, double z, String ctx) {}
        public static final List<Wp> LIST = new ArrayList<>();
        final Setting showDist = add(Setting.bool("Show Distance", true));
        final Setting size = add(Setting.slider("Text Size", 0.6f, 1.5f, 0.9f, 0.05f));
        final Setting color = add(Setting.choice("Color", 2, Colors.NAMES));

        Waypoints() {
            super("waypoints", "Waypoints", "Create and view world waypoints", Category.VISUAL);
            bind = GLFW.GLFW_KEY_B; enabled = true;
        }

        static String ctxKey(MinecraftClient mc) {
            String where = "singleplayer";
            try {
                if (mc.getCurrentServerEntry() != null) where = mc.getCurrentServerEntry().address;
                else if (mc.getServer() != null) where = "sp:" + mc.getServer().getSaveProperties().getLevelName();
            } catch (Throwable ignored) {}
            String dim = mc.world != null ? mc.world.getRegistryKey().getValue().toString() : "?";
            return where + "|" + dim;
        }

        void addHere(MinecraftClient mc) {
            if (mc.player == null) return;
            String k = ctxKey(mc);
            int n = 1;
            for (Wp w : LIST) if (w.ctx.equals(k)) n++;
            LIST.add(new Wp("WP " + n, mc.player.getX(), mc.player.getY() + 1, mc.player.getZ(), k));
            saveFile();
        }

        @Override public void onBind(MinecraftClient mc) { if (enabled) addHere(mc); else toggle(); }

        @Override public List<Action> actions() {
            MinecraftClient mc = MinecraftClient.getInstance();
            return List.of(
                new Action("Add Waypoint Here", () -> addHere(mc)),
                new Action("Delete Last", () -> {
                    String k = ctxKey(mc);
                    for (int i = LIST.size() - 1; i >= 0; i--) if (LIST.get(i).ctx.equals(k)) { LIST.remove(i); break; }
                    saveFile();
                }),
                new Action("Clear All Here", () -> { String k = ctxKey(mc); LIST.removeIf(w -> w.ctx.equals(k)); saveFile(); })
            );
        }

        void render(DrawContext c, MinecraftClient mc, int sw, int sh) {
            String k = ctxKey(mc);
            for (Wp w : LIST) {
                if (!w.ctx.equals(k)) continue;
                float[] s = Hud.project(mc, w.x, w.y, w.z, sw, sh);
                if (s == null) continue;
                int col = 0xFF000000 | Colors.RGB[color.i()];
                c.fill((int) s[0] - 2, (int) s[1] - 2, (int) s[0] + 2, (int) s[1] + 2, col);
                Hud.centeredText(c, mc, w.name, s[0], s[1] - 12, col, size.f());
                if (showDist.b()) {
                    double d = mc.player.getPos().distanceTo(new Vec3d(w.x, w.y, w.z));
                    Hud.centeredText(c, mc, (int) d + "m", s[0], s[1] + 4, 0xFFFFFFFF, size.f() * 0.85f);
                }
            }
        }

        static Path file() { return ConfigManager.root.resolve("waypoints.json"); }

        public static void saveFile() {
            try {
                JsonArray a = new JsonArray();
                for (Wp w : LIST) {
                    JsonObject o = new JsonObject();
                    o.addProperty("name", w.name); o.addProperty("x", w.x); o.addProperty("y", w.y); o.addProperty("z", w.z); o.addProperty("ctx", w.ctx);
                    a.add(o);
                }
                Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(a));
            } catch (Throwable t) { VekermanVisual.LOG.warn("waypoints save failed", t); }
        }

        public static void loadFile() {
            try {
                if (!Files.exists(file())) return;
                JsonArray a = JsonParser.parseString(Files.readString(file())).getAsJsonArray();
                LIST.clear();
                for (JsonElement e : a) {
                    JsonObject o = e.getAsJsonObject();
                    LIST.add(new Wp(o.get("name").getAsString(), o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(), o.get("ctx").getAsString()));
                }
            } catch (Throwable t) { VekermanVisual.LOG.warn("waypoints load failed", t); }
        }
    }

    // ------------------------------------------------------------- Utilities

    public static final class ToggleSprint extends Module {
        final Setting mode = add(Setting.choice("Mode", 0, "Toggle", "Hold"));
        boolean saved, prev;

        ToggleSprint() { super("togglesprint", "Toggle Sprint", "Hold or toggle sprint", Category.UTILITIES); }

        @Override public void onEnable(MinecraftClient mc) { prev = mc.options.getSprintToggled().getValue(); saved = true; }
        @Override public void onTick(MinecraftClient mc) {
            boolean want = mode.i() == 0;
            if (mc.options.getSprintToggled().getValue() != want) mc.options.getSprintToggled().setValue(want);
        }
        @Override public void onDisable(MinecraftClient mc) { if (saved) { mc.options.getSprintToggled().setValue(prev); saved = false; } }
    }

    public static final class FpsBoost extends Module {
        final Setting fast = add(Setting.bool("Fast Graphics", true));
        final Setting clouds = add(Setting.bool("Disable Clouds", true));
        final Setting shadows = add(Setting.bool("Disable Entity Shadows", true));
        final Setting dist = add(Setting.slider("Entity Distance", 0.5f, 1f, 0.75f, 0.05f));
        GraphicsMode g; CloudRenderMode cl; boolean sh; double ed; boolean saved;

        FpsBoost() {
            super("fpsboost", "FPS Boost", "Optimize rendering for more FPS", Category.UTILITIES);
            enabled = true;
        }

        @Override public void onEnable(MinecraftClient mc) {
            GameOptions o = mc.options;
            g = o.getGraphicsMode().getValue(); cl = o.getCloudRenderMode().getValue();
            sh = o.getEntityShadows().getValue(); ed = o.getEntityDistanceScaling().getValue();
            saved = true;
            if (fast.b() && g != GraphicsMode.FAST) o.getGraphicsMode().setValue(GraphicsMode.FAST);
            if (clouds.b()) o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            if (shadows.b()) o.getEntityShadows().setValue(false);
            o.getEntityDistanceScaling().setValue((double) dist.f());
        }

        @Override public void onDisable(MinecraftClient mc) {
            if (!saved) return;
            GameOptions o = mc.options;
            o.getGraphicsMode().setValue(g); o.getCloudRenderMode().setValue(cl);
            o.getEntityShadows().setValue(sh); o.getEntityDistanceScaling().setValue(ed);
            saved = false;
        }
    }

    public static final class Culling extends Module {
        final Map<Integer, Boolean> hidden = new HashMap<>();
        int t;

        Culling() { super("culling", "Entity Culling", "Don't render entities behind walls", Category.UTILITIES); }

        public static boolean isHidden(Entity e) {
            return CULLING != null && CULLING.enabled && Boolean.TRUE.equals(CULLING.hidden.get(e.getId()));
        }

        @Override public void onDisable(MinecraftClient mc) { hidden.clear(); }

        @Override public void onTick(MinecraftClient mc) {
            if (mc.world == null || mc.player == null) { hidden.clear(); return; }
            if (++t % 3 != 0) return;
            hidden.clear();
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || e.isGlowing() || e.squaredDistanceTo(cam) < 36) continue;
                Box b = e.getBoundingBox();
                Vec3d c = b.getCenter();
                Vec3d[] pts = {c, new Vec3d(c.x, b.maxY - 0.1, c.z), new Vec3d(c.x, b.minY + 0.1, c.z)};
                boolean vis = false;
                for (Vec3d p : pts) {
                    HitResult r = mc.world.raycast(new RaycastContext(cam, p, RaycastContext.ShapeType.VISUAL, RaycastContext.FluidHandling.NONE, mc.player));
                    if (r.getType() == HitResult.Type.MISS) { vis = true; break; }
                }
                if (!vis) hidden.put(e.getId(), true);
            }
        }
    }

    // ---------------------------------------------------- Config: optimization

    static final class Perf {
        static boolean lowered;
        static int savedFps = 120;
    }

    public static final class DynFps extends Module {
        final Setting bg = add(Setting.slider("Background FPS", 10, 30, 10, 1));

        DynFps() {
            super("dynfps", "Dynamic FPS", "Lower FPS when the game is minimized", Category.CONFIG);
            enabled = true;
        }

        @Override public void onTick(MinecraftClient mc) {
            boolean unfocused = !mc.isWindowFocused();
            if (unfocused && !Perf.lowered) {
                Perf.savedFps = mc.options.getMaxFps().getValue();
                mc.options.getMaxFps().setValue(bg.i());
                Perf.lowered = true;
            } else if (!unfocused && Perf.lowered) {
                mc.options.getMaxFps().setValue(Perf.savedFps);
                Perf.lowered = false;
            }
        }

        @Override public void onDisable(MinecraftClient mc) {
            if (Perf.lowered) { mc.options.getMaxFps().setValue(Perf.savedFps); Perf.lowered = false; }
        }
    }

    public static final class FastChunk extends Module {
        int blend; boolean ao, saved;

        FastChunk() { super("fastchunk", "Fast Chunk Loading", "Cheaper chunk meshing for faster loading", Category.CONFIG); }

        @Override public void onEnable(MinecraftClient mc) {
            blend = mc.options.getBiomeBlendRadius().getValue(); ao = mc.options.getAo().getValue(); saved = true;
            mc.options.getBiomeBlendRadius().setValue(1);
            mc.options.getAo().setValue(false);
        }

        @Override public void onDisable(MinecraftClient mc) {
            if (!saved) return;
            mc.options.getBiomeBlendRadius().setValue(blend); mc.options.getAo().setValue(ao); saved = false;
        }
    }

    public static final class ParticleOpt extends Module {
        public final Setting amount = add(Setting.slider("Amount (%)", 0, 100, 40, 5));

        ParticleOpt() { super("particles", "Particle Optimizer", "Fewer particles, adjustable amount", Category.CONFIG); }

        public static boolean skip() {
            return PARTICLES != null && PARTICLES.enabled && Math.random() * 100.0 >= PARTICLES.amount.f();
        }
    }

    public static final class SmoothFps extends Module {
        final Setting target = add(Setting.slider("Target FPS", 30, 120, 60, 5));
        int fps; boolean vsync, saved;

        SmoothFps() { super("smoothfps", "Smooth FPS", "Stabilize frame pacing, remove micro-freezes", Category.CONFIG); }

        @Override public void onEnable(MinecraftClient mc) {
            fps = mc.options.getMaxFps().getValue(); vsync = mc.options.getEnableVsync().getValue(); saved = true;
            mc.options.getEnableVsync().setValue(false);
        }

        @Override public void onTick(MinecraftClient mc) {
            if (!Perf.lowered && mc.options.getMaxFps().getValue() != target.i()) mc.options.getMaxFps().setValue(target.i());
        }

        @Override public void onDisable(MinecraftClient mc) {
            if (!saved) return;
            mc.options.getMaxFps().setValue(fps); mc.options.getEnableVsync().setValue(vsync); saved = false;
        }
    }

    public static final class MemoryCleaner extends Module {
        final Setting minutes = add(Setting.slider("Interval (min)", 1, 15, 5, 1));
        long last = System.currentTimeMillis();
        boolean pending;

        MemoryCleaner() {
            super("memory", "Memory Cleaner", "Free memory only while a menu is open", Category.CONFIG);
            enabled = true;
        }

        @Override public void onTick(MinecraftClient mc) {
            long now = System.currentTimeMillis();
            if (!pending && now - last > (long) (minutes.f() * 60_000L)) pending = true;
            if (pending && mc.currentScreen != null && !(mc.currentScreen instanceof ClickGuiScreen)) {
                System.gc();
                pending = false;
                last = now;
            }
        }
    }
}
