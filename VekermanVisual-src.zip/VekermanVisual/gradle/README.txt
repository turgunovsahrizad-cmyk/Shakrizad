No gradle-wrapper.jar is included (binary file). The GitHub Actions workflow installs Gradle 8.12 itself.
Locally: install Gradle 8.12+ and run `gradle build`.
